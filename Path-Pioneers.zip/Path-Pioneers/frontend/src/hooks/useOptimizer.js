import { useState } from 'react';
import { api } from '../services/api';
import { useApp } from '../context/AppContext.jsx';
import { validateProblem } from '../utils/validation';

/** Runs an algorithm on the backend using the current locations + matrix. */
export function useOptimizer() {
  const { warehouse, deliveries, distances, commitResults } = useApp();
  const [loading, setLoading] = useState(null); // null | 'greedy' | 'bb' | 'both'
  const [error, setError] = useState(null);

  async function run(kind) {
    setError(null);
    const { errors, problem } = validateProblem({ warehouse, deliveries, distances });
    if (errors.length) {
      setError(errors.join(' '));
      return;
    }
    setLoading(kind);
    try {
      if (kind === 'greedy') {
        const r = await api.greedy(problem);
        commitResults(problem, { greedy: r.greedy }, 'Greedy');
      } else if (kind === 'bb') {
        const r = await api.branchBound(problem);
        commitResults(problem, { bb: r.branch_and_bound }, 'Branch and Bound');
      } else {
        const r = await api.compare(problem);
        commitResults(problem, { greedy: r.greedy, bb: r.branch_and_bound, comparison: r.comparison }, 'Both algorithms');
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(null);
    }
  }

  return { run, loading, error, clearError: () => setError(null) };
}
