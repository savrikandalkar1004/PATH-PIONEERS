import { useCallback, useEffect, useState } from 'react';
import { api } from '../services/api';

/** Checks the backend once on mount and exposes the Branch and Bound size limit. */
export function useHealth() {
  const [health, setHealth] = useState({ checking: true, online: false, maxBB: 12, error: null });

  const refresh = useCallback(async () => {
    setHealth((h) => ({ ...h, checking: true }));
    try {
      const data = await api.health();
      setHealth({ checking: false, online: true, maxBB: data.max_branch_bound_locations, error: null });
    } catch (e) {
      setHealth((h) => ({ ...h, checking: false, online: false, error: e.message }));
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { ...health, refresh };
}
