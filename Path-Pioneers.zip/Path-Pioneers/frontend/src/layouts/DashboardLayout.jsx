import { useEffect, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  Activity, Grid3x3, Info, LayoutDashboard, MapPin, Menu, Route, Scale, X,
} from 'lucide-react';
import Logo from '../components/Logo.jsx';
import { useApp } from '../context/AppContext.jsx';

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/locations', label: 'Manage Locations', icon: MapPin },
  { to: '/matrix', label: 'Distance Matrix', icon: Grid3x3 },
  { to: '/optimizer', label: 'Route Optimizer', icon: Route },
  { to: '/comparison', label: 'Algorithm Comparison', icon: Scale },
  { to: '/performance', label: 'Performance Analysis', icon: Activity },
  { to: '/about', label: 'About Project', icon: Info },
];

export default function DashboardLayout() {
  const [open, setOpen] = useState(false);
  const { health } = useApp();
  const location = useLocation();

  useEffect(() => setOpen(false), [location.pathname]);

  const status = health.checking
    ? { dot: 'bg-slate-400', text: 'Checking backend…' }
    : health.online
    ? { dot: 'bg-success', text: 'Backend online' }
    : { dot: 'bg-red-500', text: 'Backend offline' };

  return (
    <div className="min-h-screen bg-surface">
      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between bg-navy px-4 py-3 lg:hidden">
        <Logo light />
        <button onClick={() => setOpen(true)} aria-label="Open menu" className="text-white">
          <Menu />
        </button>
      </header>

      {open && <div className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={() => setOpen(false)} />}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col bg-navy text-white transition-transform duration-200 lg:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between px-5 py-5">
          <Logo light showTagline />
          <button onClick={() => setOpen(false)} aria-label="Close menu" className="text-slate-300 lg:hidden">
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-2" aria-label="Main navigation">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                  isActive ? 'bg-primary text-white' : 'text-slate-300 hover:bg-white/10 hover:text-white'
                }`
              }
            >
              <Icon size={18} /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-white/10 px-5 py-4">
          <p className="text-[11px] italic text-slate-400">Smarter Routes. Shorter Distances. Better Deliveries.</p>
          <button onClick={health.refresh} className="mt-3 flex items-center gap-2 text-xs text-slate-300 hover:text-white" title="Click to re-check">
            <span className={`h-2 w-2 rounded-full ${status.dot}`} /> {status.text}
          </button>
        </div>
      </aside>

      <main className="lg:pl-64">
        <div key={location.pathname} className="mx-auto max-w-7xl animate-fade-in p-4 sm:p-6 lg:p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
