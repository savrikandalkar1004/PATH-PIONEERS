// Demonstration data. Both are real, hand-verifiable instances.
export const SAMPLES = [
  {
    key: 'brief',
    label: 'Brief example (4 locations)',
    description: 'Greedy and Branch and Bound both find distance 80.',
    locations: ['Warehouse', 'A', 'B', 'C'],
    matrix: [
      [0, 10, 15, 20],
      [10, 0, 35, 25],
      [15, 35, 0, 30],
      [20, 25, 30, 0],
    ],
  },
  {
    key: 'greedy-fails',
    label: 'Greedy fails (5 locations)',
    description: 'Greedy gives 52, the optimum is 45.',
    locations: ['Warehouse', 'A', 'B', 'C', 'D'],
    matrix: [
      [0, 16, 14, 2, 3],
      [16, 0, 18, 19, 11],
      [14, 18, 0, 11, 12],
      [2, 19, 11, 0, 20],
      [3, 11, 12, 20, 0],
    ],
  },
];
