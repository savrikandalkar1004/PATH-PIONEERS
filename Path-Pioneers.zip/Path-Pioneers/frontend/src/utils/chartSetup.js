// Registers the Chart.js pieces we use (import this once from any chart page).
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  Legend,
  LinearScale,
  LineElement,
  LogarithmicScale,
  PointElement,
  Title,
  Tooltip,
} from 'chart.js';

ChartJS.register(BarElement, CategoryScale, Legend, LinearScale, LineElement, LogarithmicScale, PointElement, Title, Tooltip);

export const COLORS = { greedy: '#F59E0B', bb: '#2563EB', navy: '#101B35' };
