// Small formatting helpers shared by pages and components.

export function formatMs(seconds) {
  return formatMsValue(seconds * 1000);
}

export function formatMsValue(ms) {
  if (ms >= 100) return `${ms.toFixed(1)} ms`;
  if (ms >= 1) return `${ms.toFixed(2)} ms`;
  return `${ms.toFixed(4)} ms`;
}

export function formatDistance(x) {
  if (x === null || x === undefined || Number.isNaN(x)) return '—';
  return Number.isInteger(x) ? String(x) : String(Number(x.toFixed(2)));
}

export function formatPercent(x) {
  if (x === null || x === undefined || Number.isNaN(x)) return '—';
  return `${x.toFixed(2)}%`;
}

export function formatTime(date) {
  return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

/**
 * Improvement (%) = ((Greedy - Optimal) / Greedy) * 100, safe when Greedy is 0.
 * Used only as a fallback when the two algorithms were run separately;
 * the /compare endpoint returns the same figure computed by the backend.
 */
export function improvementPercent(greedyDistance, optimalDistance) {
  if (!greedyDistance) return 0;
  return ((greedyDistance - optimalDistance) / greedyDistance) * 100;
}

/** Comparison info from the backend if present, otherwise derived from both distances. */
export function getComparison(results) {
  if (!results?.greedy || !results?.bb) return null;
  if (results.comparison) return results.comparison;
  const saved = results.greedy.distance - results.bb.distance;
  return {
    distance_saved: saved,
    improvement_percent: improvementPercent(results.greedy.distance, results.bb.distance),
    greedy_is_optimal: saved <= 1e-9,
    same_route: JSON.stringify(results.greedy.route_indices) === JSON.stringify(results.bb.route_indices),
  };
}
