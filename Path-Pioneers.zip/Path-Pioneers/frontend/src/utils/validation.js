// Distance matrix helpers + validation (mirrors the rules enforced by the backend).

/** Distances are symmetric, so (a,b) and (b,a) share one key. */
export const pairKey = (a, b) => (a < b ? `${a}|${b}` : `${b}|${a}`);

/** 'missing' | 'invalid' | 'ok' for a raw input value. */
export function cellStatus(value) {
  if (value === undefined || value === null || String(value).trim() === '') return 'missing';
  const x = Number(value);
  if (!Number.isFinite(x) || x < 0) return 'invalid';
  return 'ok';
}

/** Matrix of display strings ('' where the user has not entered a value). */
export function buildMatrixStrings(locations, distances) {
  return locations.map((a, i) =>
    locations.map((b, j) => (i === j ? '0' : distances[pairKey(a.id, b.id)] ?? ''))
  );
}

/**
 * Checks everything the optimizer needs.
 * Returns { errors: string[], problem: {locations, distance_matrix} | null }.
 */
export function validateProblem({ warehouse, deliveries, distances }) {
  const errors = [];
  if (!warehouse) errors.push('Add a warehouse (the starting location) first.');
  if (deliveries.length < 2) errors.push('Add at least 2 delivery locations.');
  if (errors.length) return { errors, problem: null };

  const locs = [warehouse, ...deliveries];
  let missing = 0;
  let invalid = 0;
  const matrix = locs.map((a, i) =>
    locs.map((b, j) => {
      if (i === j) return 0;
      const raw = distances[pairKey(a.id, b.id)];
      const status = cellStatus(raw);
      if (status === 'missing') { if (i < j) missing += 1; return NaN; }
      if (status === 'invalid') { if (i < j) invalid += 1; return NaN; }
      return Number(raw);
    })
  );

  if (missing) errors.push(`${missing} distance${missing > 1 ? 's are' : ' is'} still empty in the distance matrix.`);
  if (invalid) errors.push(`${invalid} distance${invalid > 1 ? 's are' : ' is'} invalid (distances must be non-negative numbers).`);
  if (errors.length) return { errors, problem: null };

  return { errors: [], problem: { locations: locs.map((l) => l.name), distance_matrix: matrix } };
}
