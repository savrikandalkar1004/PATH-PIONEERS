import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { useHealth } from '../hooks/useHealth';
import { pairKey } from '../utils/validation';

/**
 * Global app state (React state only - no database, as required).
 *  warehouse / deliveries : locations, each { id, name }
 *  distances              : { 'idA|idB': '12' }  (one entry per unordered pair => symmetric)
 *  results                : latest algorithm output + the exact problem it was computed from
 *  history                : recent optimization runs in this session
 *  perf                   : last performance-analysis response
 */
const AppContext = createContext(null);

export const MAX_NAME_LENGTH = 30;
export const MAX_LOCATIONS = 30; // warehouse included (keeps the matrix editor usable)

let counter = 0;
const newId = () => `loc${Date.now().toString(36)}${(counter++).toString(36)}`;

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}

export function AppProvider({ children }) {
  const health = useHealth();
  const [warehouse, setWarehouse] = useState(null);
  const [deliveries, setDeliveries] = useState([]);
  const [distances, setDistances] = useState({});
  const [results, setResults] = useState(null);
  const [history, setHistory] = useState([]);
  const [perf, setPerf] = useState(null);

  const locations = useMemo(() => (warehouse ? [warehouse, ...deliveries] : [...deliveries]), [warehouse, deliveries]);

  /** Returns an error message, or null if the name is acceptable. */
  const checkName = useCallback(
    (raw, excludeId = null) => {
      const name = raw.trim();
      if (!name) return 'Name cannot be empty.';
      if (name.length > MAX_NAME_LENGTH) return `Name must be at most ${MAX_NAME_LENGTH} characters.`;
      if (locations.some((l) => l.id !== excludeId && l.name.toLowerCase() === name.toLowerCase())) {
        return `"${name}" already exists. Location names must be unique.`;
      }
      return null;
    },
    [locations]
  );

  const clearResults = useCallback(() => setResults(null), []);

  // ---- location actions (each returns an error string or null) ----
  const saveWarehouse = (raw) => {
    const err = checkName(raw, warehouse?.id);
    if (err) return err;
    const name = raw.trim();
    setWarehouse((w) => (w ? { ...w, name } : { id: newId(), name }));
    return null;
  };

  const addDelivery = (raw) => {
    const err = checkName(raw);
    if (err) return err;
    if (locations.length >= MAX_LOCATIONS) return `At most ${MAX_LOCATIONS} locations are supported in the interface.`;
    setDeliveries((d) => [...d, { id: newId(), name: raw.trim() }]);
    return null;
  };

  const renameLocation = (id, raw) => {
    const err = checkName(raw, id);
    if (err) return err;
    const name = raw.trim();
    if (warehouse?.id === id) setWarehouse((w) => ({ ...w, name }));
    else setDeliveries((d) => d.map((l) => (l.id === id ? { ...l, name } : l)));
    return null;
  };

  const removeLocation = (id) => {
    if (warehouse?.id === id) setWarehouse(null);
    else setDeliveries((d) => d.filter((l) => l.id !== id));
    // drop every distance that involved this location
    setDistances((prev) => {
      const next = {};
      Object.entries(prev).forEach(([key, value]) => {
        if (!key.split('|').includes(id)) next[key] = value;
      });
      return next;
    });
  };

  const clearAll = () => {
    setWarehouse(null);
    setDeliveries([]);
    setDistances({});
    setResults(null);
  };

  // ---- distance actions ----
  const setDistance = (idA, idB, value) => {
    setDistances((prev) => {
      const next = { ...prev };
      if (value === '') delete next[pairKey(idA, idB)];
      else next[pairKey(idA, idB)] = value; // symmetric: one key for (A,B) and (B,A)
      return next;
    });
  };

  const resetMatrix = () => setDistances({});

  const loadSample = (sample) => {
    const locs = sample.locations.map((name) => ({ id: newId(), name }));
    const next = {};
    locs.forEach((a, i) =>
      locs.forEach((b, j) => {
        if (i < j) next[pairKey(a.id, b.id)] = String(sample.matrix[i][j]);
      })
    );
    setWarehouse(locs[0]);
    setDeliveries(locs.slice(1));
    setDistances(next);
    setResults(null);
  };

  // ---- results ----
  const commitResults = (problem, partial, label) => {
    const key = JSON.stringify(problem);
    setResults((prev) => {
      const same = prev && JSON.stringify(prev.problem) === key;
      const base = same ? prev : { problem };
      const merged = { ...base, ...partial };
      // a single-algorithm run invalidates a stale backend comparison
      if (!partial.comparison) delete merged.comparison;
      return merged;
    });
    setHistory((h) =>
      [
        {
          id: `${Date.now()}-${h.length}`,
          at: Date.now(),
          label,
          deliveries: problem.locations.length - 1,
          greedy: partial.greedy?.distance ?? null,
          bb: partial.bb?.distance ?? null,
          saved: partial.comparison?.distance_saved ?? null,
        },
        ...h,
      ].slice(0, 8)
    );
  };

  const value = {
    health,
    warehouse,
    deliveries,
    locations,
    distances,
    results,
    history,
    perf,
    setPerf,
    checkName,
    saveWarehouse,
    addDelivery,
    renameLocation,
    removeLocation,
    clearAll,
    setDistance,
    resetMatrix,
    loadSample,
    commitResults,
    clearResults,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
