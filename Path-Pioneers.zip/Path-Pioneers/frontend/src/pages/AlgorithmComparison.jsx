import { Link } from 'react-router-dom';
import { Bar } from 'react-chartjs-2';
import { BadgeCheck, Scale, TriangleAlert } from 'lucide-react';
import { COLORS } from '../utils/chartSetup';
import { Alert, Card, EmptyState, PageHeader } from '../components/ui.jsx';
import { useApp } from '../context/AppContext.jsx';
import { formatDistance, formatMs, formatPercent, getComparison } from '../utils/format';

function barOptions(title, yTitle) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false }, title: { display: true, text: title } },
    scales: { y: { beginAtZero: true, title: { display: true, text: yTitle } } },
  };
}

export default function AlgorithmComparison() {
  const { results } = useApp();
  const comparison = getComparison(results);

  if (!comparison) {
    return (
      <>
        <PageHeader title="Algorithm Comparison" subtitle="Greedy Nearest Neighbour vs Branch and Bound on the same input." />
        <EmptyState icon={Scale} title="Run both algorithms first" action={<Link to="/optimizer" className="btn btn-primary">Go to Route Optimizer</Link>}>
          The comparison needs a Greedy result and a Branch and Bound result for the same locations and distances.
        </EmptyState>
      </>
    );
  }

  const { greedy, bb } = results;
  const labels = ['Greedy', 'Branch and Bound'];
  const colors = [COLORS.greedy, COLORS.bb];
  const distanceData = { labels, datasets: [{ data: [greedy.distance, bb.distance], backgroundColor: colors, borderRadius: 8 }] };
  const timeData = { labels, datasets: [{ data: [greedy.execution_time_ms, bb.execution_time_ms], backgroundColor: colors, borderRadius: 8 }] };

  const rows = [
    ['Total route distance', formatDistance(greedy.distance), formatDistance(bb.distance)],
    ['Execution time', formatMs(greedy.execution_time), formatMs(bb.execution_time)],
    ['Route sequence', greedy.route.join(' → '), bb.route.join(' → ')],
    ['Optimality', 'Not guaranteed (heuristic)', 'Guaranteed optimal'],
    ['Time complexity', 'O(n²)', 'O(n!) worst case'],
    ['Space complexity', 'O(n)', 'O(n²) (recursion stack + per-level unvisited lists)'],
    ['Search effort', 'n − 1 greedy steps', `${bb.nodes_explored?.toLocaleString() ?? '—'} nodes explored, ${bb.branches_pruned?.toLocaleString() ?? '—'} pruned`],
  ];

  return (
    <div className="space-y-6">
      <PageHeader title="Algorithm Comparison" subtitle="Both algorithms solved exactly the same distance matrix." />

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="!p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Distance saved</div>
          <div className="text-2xl font-bold text-success">{formatDistance(comparison.distance_saved)}</div>
        </Card>
        <Card className="!p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Improvement over Greedy</div>
          <div className="text-2xl font-bold text-navy">{formatPercent(comparison.improvement_percent)}</div>
        </Card>
        <Card className="!p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Same route?</div>
          <div className="text-2xl font-bold text-navy">{comparison.same_route ? 'Yes' : 'No'}</div>
        </Card>
      </div>

      <Card>
        <p className="text-sm text-slate-600">
          <strong>Improvement (%)</strong> = ((Greedy distance − Optimal distance) ÷ Greedy distance) × 100 =
          (({formatDistance(greedy.distance)} − {formatDistance(bb.distance)}) ÷ {formatDistance(greedy.distance)}) × 100 ={' '}
          <strong>{formatPercent(comparison.improvement_percent)}</strong>
          {greedy.distance === 0 && ' (Greedy distance is 0, so the improvement is defined as 0%).'}
        </p>
      </Card>

      {comparison.greedy_is_optimal ? (
        <Alert tone="success" title="Greedy was optimal here">
          On this input the Greedy route happens to be as short as the optimum. That is luck, not a guarantee: Greedy can
          be forced into long final legs on other inputs.
        </Alert>
      ) : (
        <Alert tone="warning" title="Greedy was not optimal here">
          Always taking the nearest unvisited location left Greedy with longer legs later. Branch and Bound found a shorter tour.
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-l-4 border-l-warning">
          <h3 className="flex items-center gap-2 font-bold text-navy"><TriangleAlert size={16} className="text-warning" /> Greedy Nearest Neighbour</h3>
          <p className="mt-1 text-sm text-slate-600">A fast heuristic. It does <strong>not</strong> guarantee an optimal route.</p>
        </Card>
        <Card className="border-l-4 border-l-primary">
          <h3 className="flex items-center gap-2 font-bold text-navy"><BadgeCheck size={16} className="text-primary" /> Branch and Bound</h3>
          <p className="mt-1 text-sm text-slate-600">An exact search with a valid lower bound. It <strong>guarantees</strong> the minimum distance for this TSP definition.</p>
        </Card>
      </div>

      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-100">
            <thead className="bg-slate-50">
              <tr><th className="th">Metric</th><th className="th text-warning">Greedy</th><th className="th text-primary">Branch and Bound</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map(([metric, g, b]) => (
                <tr key={metric}>
                  <td className="td font-semibold text-navy">{metric}</td>
                  <td className="td">{g}</td>
                  <td className="td">{b}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card><div className="h-72"><Bar data={distanceData} options={barOptions('Route distance', 'Distance')} /></div></Card>
        <Card><div className="h-72"><Bar data={timeData} options={barOptions('Execution time', 'Milliseconds')} /></div></Card>
      </div>
      <p className="text-xs text-slate-500">
        Execution time is a single measured run on this machine (Python <code>time.perf_counter()</code>), so it varies between
        runs. Use the Performance Analysis page for repeated, median-based measurements. For Branch and Bound the time includes
        the Greedy tour it uses as its starting upper bound.
      </p>
    </div>
  );
}
