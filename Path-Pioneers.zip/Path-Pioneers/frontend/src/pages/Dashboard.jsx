import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Clock, FlaskConical, Package, Route, Ruler, TrendingDown, Zap } from 'lucide-react';
import { LogoMark } from '../components/Logo.jsx';
import { Card, EmptyState, StatCard } from '../components/ui.jsx';
import { useApp } from '../context/AppContext.jsx';
import { formatDistance, formatTime, getComparison } from '../utils/format';
import { SAMPLES } from '../utils/samples';

export default function Dashboard() {
  const { deliveries, warehouse, results, history, loadSample } = useApp();
  const navigate = useNavigate();
  const comparison = getComparison(results);
  const ready = warehouse && deliveries.length >= 2;

  return (
    <div className="space-y-6">
      <section className="rounded-2xl bg-navy p-6 text-white shadow-card sm:p-8">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="max-w-2xl">
            <div className="mb-4 flex items-center gap-3">
              <LogoMark size={44} />
              <span className="text-lg font-extrabold tracking-wide">PATH PIONEERS</span>
            </div>
            <h1 className="text-2xl font-bold sm:text-3xl">Welcome to your delivery route optimizer</h1>
            <p className="mt-2 text-sm text-slate-300">
              Plan one vehicle's tour from the warehouse through every delivery stop and back. Path Pioneers solves the
              Travelling Salesman Problem with the Greedy Nearest Neighbour heuristic and an exact Branch and Bound
              search, then compares distance, optimality and running time.
            </p>
            <p className="mt-3 text-xs italic text-slate-400">Smarter Routes. Shorter Distances. Better Deliveries.</p>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row md:flex-col">
            <button className="btn btn-primary" onClick={() => navigate(ready ? '/optimizer' : '/locations')}>
              <Zap size={16} /> Start Route Optimization
            </button>
            <button className="btn bg-white/10 text-white hover:bg-white/20" onClick={() => { loadSample(SAMPLES[1]); navigate('/optimizer'); }}>
              <FlaskConical size={16} /> Load demo data
            </button>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard icon={Package} label="Delivery locations" value={deliveries.length} hint={warehouse ? `Warehouse: ${warehouse.name}` : 'No warehouse yet'} />
        <StatCard icon={Ruler} tone="orange" label="Greedy distance" value={results?.greedy ? formatDistance(results.greedy.distance) : '—'} hint={results?.greedy ? 'Latest run' : 'Not run yet'} />
        <StatCard icon={Ruler} tone="navy" label="Branch and Bound" value={results?.bb ? formatDistance(results.bb.distance) : '—'} hint={results?.bb ? 'Optimal distance' : 'Not run yet'} />
        <StatCard icon={TrendingDown} tone="green" label="Distance saved" value={comparison ? formatDistance(comparison.distance_saved) : '—'} hint={comparison ? `${comparison.improvement_percent.toFixed(2)}% shorter than Greedy` : 'Run both algorithms'} />
      </div>

      <Card>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-bold text-navy"><Clock size={18} /> Recent optimization results</h2>
          <span className="text-xs text-slate-500">This session only</span>
        </div>
        {history.length === 0 ? (
          <EmptyState icon={Route} title="No runs yet" action={<Link to={ready ? '/optimizer' : '/locations'} className="btn btn-primary btn-sm">Get started <ArrowRight size={14} /></Link>}>
            Add locations and run an algorithm. Your results for this session will be listed here.
          </EmptyState>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-100">
              <thead>
                <tr>
                  <th className="th">Time</th><th className="th">Run</th><th className="th">Deliveries</th>
                  <th className="th">Greedy</th><th className="th">Branch and Bound</th><th className="th">Saved</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {history.map((h) => (
                  <tr key={h.id}>
                    <td className="td tabular-nums text-slate-500">{formatTime(h.at)}</td>
                    <td className="td font-medium">{h.label}</td>
                    <td className="td">{h.deliveries}</td>
                    <td className="td">{h.greedy === null ? '—' : formatDistance(h.greedy)}</td>
                    <td className="td">{h.bb === null ? '—' : formatDistance(h.bb)}</td>
                    <td className="td">{h.saved === null ? '—' : formatDistance(h.saved)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
