import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, MapPin, Pencil, Plus, Trash2, Warehouse, X } from 'lucide-react';
import { Alert, Card, EmptyState, PageHeader } from '../components/ui.jsx';
import { MAX_LOCATIONS, MAX_NAME_LENGTH, useApp } from '../context/AppContext.jsx';

/** Name input + button row that reports validation errors from the context. */
function AddForm({ placeholder, buttonLabel, onSubmit, icon: Icon = Plus, initial = '' }) {
  const [value, setValue] = useState(initial);
  const [error, setError] = useState(null);

  function submit(e) {
    e.preventDefault();
    const err = onSubmit(value);
    if (err) setError(err);
    else {
      setValue(initial ? value : '');
      setError(null);
    }
  }

  return (
    <form onSubmit={submit} noValidate>
      <div className="flex flex-col gap-2 sm:flex-row">
        <input
          className={`input ${error ? '!border-red-400' : ''}`}
          value={value}
          maxLength={MAX_NAME_LENGTH + 10}
          placeholder={placeholder}
          aria-label={placeholder}
          aria-invalid={Boolean(error)}
          onChange={(e) => { setValue(e.target.value); setError(null); }}
        />
        <button type="submit" className="btn btn-primary whitespace-nowrap"><Icon size={16} /> {buttonLabel}</button>
      </div>
      {error && <p className="mt-1.5 text-xs text-red-600" role="alert">{error}</p>}
    </form>
  );
}

/** One row of the locations table with inline rename + delete. */
function LocationRow({ index, loc, isWarehouse }) {
  const { renameLocation, removeLocation } = useApp();
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(loc.name);
  const [error, setError] = useState(null);

  function save() {
    const err = renameLocation(loc.id, value);
    if (err) setError(err);
    else { setEditing(false); setError(null); }
  }

  return (
    <tr>
      <td className="td text-slate-500">{index}</td>
      <td className="td font-mono text-xs text-slate-400">{loc.id}</td>
      <td className="td">
        {editing ? (
          <div>
            <input
              autoFocus
              className="input !py-1.5"
              value={value}
              aria-label={`New name for ${loc.name}`}
              onChange={(e) => { setValue(e.target.value); setError(null); }}
              onKeyDown={(e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') { setEditing(false); setValue(loc.name); setError(null); } }}
            />
            {error && <p className="mt-1 text-xs text-red-600" role="alert">{error}</p>}
          </div>
        ) : (
          <span className="font-semibold text-navy">{loc.name}</span>
        )}
      </td>
      <td className="td">
        <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${isWarehouse ? 'bg-navy text-white' : 'bg-blue-50 text-primary'}`}>
          {isWarehouse ? 'Warehouse' : 'Delivery'}
        </span>
      </td>
      <td className="td">
        <div className="flex justify-end gap-1">
          {editing ? (
            <>
              <button className="btn btn-secondary btn-sm" onClick={save} aria-label="Save name"><Check size={14} /></button>
              <button className="btn btn-secondary btn-sm" onClick={() => { setEditing(false); setValue(loc.name); setError(null); }} aria-label="Cancel"><X size={14} /></button>
            </>
          ) : (
            <>
              <button className="btn btn-secondary btn-sm" onClick={() => { setValue(loc.name); setEditing(true); }} aria-label={`Rename ${loc.name}`}><Pencil size={14} /></button>
              <button className="btn btn-danger btn-sm" onClick={() => removeLocation(loc.id)} aria-label={`Delete ${loc.name}`}><Trash2 size={14} /></button>
            </>
          )}
        </div>
      </td>
    </tr>
  );
}

export default function ManageLocations() {
  const { warehouse, deliveries, locations, saveWarehouse, addDelivery, clearAll } = useApp();
  const ready = warehouse && deliveries.length >= 2;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Manage Locations"
        subtitle="Define the warehouse (the start and end of the tour) and every delivery destination. Names must be unique."
        action={locations.length > 0 && (
          <button className="btn btn-secondary" onClick={() => { if (window.confirm('Remove all locations and distances?')) clearAll(); }}>
            <Trash2 size={16} /> Clear all
          </button>
        )}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="mb-1 flex items-center gap-2 text-base font-bold text-navy"><Warehouse size={18} /> Warehouse</h2>
          <p className="mb-3 text-xs text-slate-500">Exactly one. The vehicle starts and finishes here.</p>
          {warehouse ? (
            <p className="mb-3 text-sm">Current warehouse: <strong className="text-navy">{warehouse.name}</strong>. Use the table below to rename or remove it.</p>
          ) : (
            <AddForm placeholder="Warehouse name, e.g. Central Depot" buttonLabel="Add warehouse" onSubmit={saveWarehouse} icon={Warehouse} />
          )}
        </Card>
        <Card>
          <h2 className="mb-1 flex items-center gap-2 text-base font-bold text-navy"><MapPin size={18} /> Delivery location</h2>
          <p className="mb-3 text-xs text-slate-500">Add at least 2. Each is visited exactly once.</p>
          <AddForm placeholder="Delivery location name, e.g. Shivajinagar" buttonLabel="Add location" onSubmit={addDelivery} />
          <p className="mt-2 text-xs text-slate-400">{locations.length} / {MAX_LOCATIONS} locations used</p>
        </Card>
      </div>

      {locations.length === 0 ? (
        <EmptyState icon={MapPin} title="No locations yet">Add your warehouse first, then your delivery destinations.</EmptyState>
      ) : (
        <Card className="!p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-100">
              <thead className="bg-slate-50">
                <tr>
                  <th className="th">#</th><th className="th">ID</th><th className="th">Name</th><th className="th">Type</th><th className="th text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {locations.map((loc, i) => (
                  <LocationRow key={loc.id} index={i} loc={loc} isWarehouse={warehouse?.id === loc.id} />
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {locations.length > 0 && !ready && (
        <Alert tone="info">
          {!warehouse ? 'A warehouse is required. ' : ''}
          {deliveries.length < 2 ? `Add ${2 - deliveries.length} more delivery location${deliveries.length === 1 ? '' : 's'} to be able to optimize.` : ''}
        </Alert>
      )}
      {ready && (
        <div className="flex justify-end">
          <Link to="/matrix" className="btn btn-primary">Continue to distance matrix <ArrowRight size={16} /></Link>
        </div>
      )}
    </div>
  );
}
