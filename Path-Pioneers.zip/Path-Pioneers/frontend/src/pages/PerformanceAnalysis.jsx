import { useState } from 'react';
import { Line } from 'react-chartjs-2';
import { Activity, Play } from 'lucide-react';
import { COLORS } from '../utils/chartSetup';
import { Alert, Card, EmptyState, PageHeader, Spinner } from '../components/ui.jsx';
import { useApp } from '../context/AppContext.jsx';
import { api } from '../services/api';
import { formatDistance, formatMsValue, formatPercent } from '../utils/format';

const MAX_SIZES = 15;

/** "3, 4 5,6" -> [3,4,5,6]; returns { sizes } or { error }. */
function parseSizes(text) {
  const parts = text.split(/[\s,]+/).filter(Boolean);
  if (parts.length === 0) return { error: 'Enter at least one size, for example: 3, 4, 5, 6, 7, 8.' };
  const sizes = [];
  for (const p of parts) {
    const x = Number(p);
    if (!Number.isInteger(x) || x < 1 || x > 200) return { error: `"${p}" is not a whole number between 1 and 200.` };
    sizes.push(x);
  }
  const unique = [...new Set(sizes)].sort((a, b) => a - b);
  if (unique.length > MAX_SIZES) return { error: `Use at most ${MAX_SIZES} different sizes.` };
  return { sizes: unique };
}

function lineOptions(title, yTitle, log) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { title: { display: true, text: title }, legend: { position: 'bottom' } },
    scales: {
      x: { title: { display: true, text: 'Delivery locations' } },
      y: { type: log ? 'logarithmic' : 'linear', beginAtZero: !log, title: { display: true, text: yTitle } },
    },
  };
}

export default function PerformanceAnalysis() {
  const { perf, setPerf, health } = useApp();
  const [sizesText, setSizesText] = useState('3, 4, 5, 6, 7, 8, 9, 10');
  const [repeats, setRepeats] = useState(5);
  const [seed, setSeed] = useState('42');
  const [logScale, setLogScale] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const maxDeliveries = health.maxBB - 1;
  const presets = [
    { label: 'Small (3–8)', text: '3, 4, 5, 6, 7, 8' },
    { label: `Up to the limit (3–${maxDeliveries})`, text: Array.from({ length: Math.max(maxDeliveries - 2, 1) }, (_, i) => i + 3).join(', ') },
    { label: 'Past the limit (Greedy only beyond)', text: `5, 8, ${maxDeliveries}, ${maxDeliveries + 3}, 50, 100` },
  ];

  async function runTest(e) {
    e.preventDefault();
    setError(null);
    const parsed = parseSizes(sizesText);
    if (parsed.error) return setError(parsed.error);
    const reps = Number(repeats);
    if (!Number.isInteger(reps) || reps < 1 || reps > 10) return setError('Repetitions must be a whole number from 1 to 10.');
    if (seed.trim() !== '' && !Number.isInteger(Number(seed))) return setError('Seed must be a whole number (or left empty for random).');

    setLoading(true);
    try {
      const data = await api.performance({
        sizes: parsed.sizes,
        repeats: reps,
        ...(seed.trim() !== '' ? { seed: Number(seed) } : {}),
      });
      setPerf(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  const rows = perf?.results ?? [];
  const labels = rows.map((r) => r.delivery_locations);
  const timeData = {
    labels,
    datasets: [
      { label: 'Greedy', data: rows.map((r) => r.greedy.median_time_ms), borderColor: COLORS.greedy, backgroundColor: COLORS.greedy, tension: 0.25 },
      { label: 'Branch and Bound', data: rows.map((r) => r.branch_and_bound?.median_time_ms ?? null), borderColor: COLORS.bb, backgroundColor: COLORS.bb, tension: 0.25, spanGaps: false },
    ],
  };
  const distanceData = {
    labels,
    datasets: [
      { label: 'Greedy', data: rows.map((r) => r.greedy.distance), borderColor: COLORS.greedy, backgroundColor: COLORS.greedy, tension: 0.25 },
      { label: 'Branch and Bound (optimal)', data: rows.map((r) => r.branch_and_bound?.distance ?? null), borderColor: COLORS.bb, backgroundColor: COLORS.bb, tension: 0.25, spanGaps: false },
    ],
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Performance Analysis"
        subtitle="Measure both algorithms on random instances of different sizes. Every number comes from a real run on the backend, nothing is hard-coded."
      />

      <Card>
        <form onSubmit={runTest} className="space-y-4" noValidate>
          <div className="grid gap-4 md:grid-cols-3">
            <label className="block md:col-span-3">
              <span className="text-sm font-semibold text-navy">Delivery location counts to test</span>
              <input className="input mt-1" value={sizesText} onChange={(e) => setSizesText(e.target.value)} placeholder="3, 4, 5, 6, 7, 8" />
              <span className="mt-1 block text-xs text-slate-500">
                Comma-separated. Branch and Bound runs only up to {maxDeliveries} delivery locations ({health.maxBB} including the warehouse); larger sizes run Greedy only.
              </span>
            </label>
            <label className="block">
              <span className="text-sm font-semibold text-navy">Repetitions per size</span>
              <input type="number" min="1" max="10" className="input mt-1" value={repeats} onChange={(e) => setRepeats(e.target.value)} />
              <span className="mt-1 block text-xs text-slate-500">The median time is reported.</span>
            </label>
            <label className="block">
              <span className="text-sm font-semibold text-navy">Random seed (optional)</span>
              <input className="input mt-1" value={seed} onChange={(e) => setSeed(e.target.value)} placeholder="empty = random" />
              <span className="mt-1 block text-xs text-slate-500">Same seed = same test matrices.</span>
            </label>
            <div className="flex items-end">
              <button className="btn btn-primary w-full" disabled={loading}>
                {loading ? <Spinner /> : <Play size={16} />} {loading ? 'Measuring…' : 'Run performance test'}
              </button>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {presets.map((p) => (
              <button type="button" key={p.label} className="btn btn-secondary btn-sm" onClick={() => setSizesText(p.text)}>{p.label}</button>
            ))}
          </div>
          {error && <Alert tone="error" title="Cannot run the test" onClose={() => setError(null)}>{error}</Alert>}
        </form>
      </Card>

      {rows.length === 0 ? (
        <EmptyState icon={Activity} title="No measurements yet">
          Choose some sizes and run the test. Charts and the comparison table will appear here.
        </EmptyState>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-navy">Results</h2>
            <label className="flex items-center gap-2 text-sm text-slate-600">
              <input type="checkbox" checked={logScale} onChange={(e) => setLogScale(e.target.checked)} /> Log scale for time
            </label>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card><div className="h-80"><Line data={timeData} options={lineOptions('Execution time vs number of locations (median)', 'Milliseconds', logScale)} /></div></Card>
            <Card><div className="h-80"><Line data={distanceData} options={lineOptions('Route distance vs number of locations', 'Total distance', false)} /></div></Card>
          </div>

          <Card className="!p-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-100">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="th">Deliveries</th><th className="th">Greedy distance</th><th className="th">Greedy time</th>
                    <th className="th">B&amp;B distance</th><th className="th">B&amp;B time</th><th className="th">B&amp;B nodes explored</th><th className="th">Improvement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rows.map((r) => (
                    <tr key={r.delivery_locations}>
                      <td className="td font-semibold text-navy">{r.delivery_locations}</td>
                      <td className="td">{formatDistance(r.greedy.distance)}</td>
                      <td className="td tabular-nums">{formatMsValue(r.greedy.median_time_ms)}</td>
                      {r.branch_and_bound ? (
                        <>
                          <td className="td">{formatDistance(r.branch_and_bound.distance)}</td>
                          <td className="td tabular-nums">{formatMsValue(r.branch_and_bound.median_time_ms)}</td>
                          <td className="td tabular-nums">{r.branch_and_bound.nodes_explored.toLocaleString()}</td>
                          <td className="td">{formatPercent(r.improvement_percent)}</td>
                        </>
                      ) : (
                        <td className="td text-slate-500" colSpan={4}>Skipped (above the Branch and Bound limit)</td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          <Alert tone="info" title="How to read these numbers">
            Each size uses one random symmetric matrix (integer distances 1–100){perf.seed !== null ? ` generated with seed ${perf.seed}` : ''}.
            Each algorithm ran {perf.repeats} time{perf.repeats > 1 ? 's' : ''} and the median is shown. Timings depend on your hardware and on
            Python, so they are comparable within this table but not across machines. Branch and Bound times also depend on the instance: pruning
            works better on some matrices than others.
          </Alert>
        </>
      )}

      <Card>
        <h2 className="mb-2 text-base font-bold text-navy">Time complexity explained</h2>
        <div className="grid gap-4 text-sm text-slate-600 md:grid-cols-2">
          <div>
            <h3 className="font-semibold text-warning">Greedy: O(n²)</h3>
            <p>It makes n − 1 moves and each move scans up to n locations for the nearest unvisited one, so the work grows like n². Doubling the locations roughly quadruples the time, which is why Greedy stays fast even for hundreds of stops.</p>
          </div>
          <div>
            <h3 className="font-semibold text-primary">Branch and Bound: O(n!) worst case</h3>
            <p>There are (n − 1)! possible tours. Branch and Bound cuts every partial route whose lower bound cannot beat the best tour found so far, which usually removes most of them, but if the bound is weak nothing is pruned and all (n − 1)! tours are examined. Hence the size limit.</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
