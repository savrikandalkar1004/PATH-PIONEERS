import { Link } from 'react-router-dom';
import { ArrowRight, FlaskConical, Grid3x3, MapPin, RotateCcw } from 'lucide-react';
import { Alert, Card, EmptyState, PageHeader } from '../components/ui.jsx';
import { useApp } from '../context/AppContext.jsx';
import { SAMPLES } from '../utils/samples';
import { cellStatus, pairKey } from '../utils/validation';

export default function DistanceMatrix() {
  const { locations, distances, setDistance, resetMatrix, loadSample } = useApp();

  const total = (locations.length * (locations.length - 1)) / 2; // unique pairs
  let filled = 0;
  let invalid = 0;
  for (let i = 0; i < locations.length; i += 1) {
    for (let j = i + 1; j < locations.length; j += 1) {
      const s = cellStatus(distances[pairKey(locations[i].id, locations[j].id)]);
      if (s === 'ok') filled += 1;
      if (s === 'invalid') invalid += 1;
    }
  }

  function onLoadSample(sample) {
    if (locations.length && !window.confirm('Loading a sample replaces your current locations and distances. Continue?')) return;
    loadSample(sample);
  }

  const header = (
    <PageHeader
      title="Distance Matrix"
      subtitle="Enter the distance between every pair of locations. The matrix is symmetric: editing A→B updates B→A automatically, and the diagonal is always 0."
      action={
        <>
          {SAMPLES.map((s) => (
            <button key={s.key} className="btn btn-secondary" title={s.description} onClick={() => onLoadSample(s)}>
              <FlaskConical size={16} /> {s.label}
            </button>
          ))}
          <button className="btn btn-secondary" onClick={() => { if (window.confirm('Clear every entered distance?')) resetMatrix(); }} disabled={filled === 0 && invalid === 0}>
            <RotateCcw size={16} /> Reset matrix
          </button>
        </>
      }
    />
  );

  if (locations.length < 2) {
    return (
      <>
        {header}
        <EmptyState
          icon={Grid3x3}
          title="Add locations first"
          action={<Link to="/locations" className="btn btn-primary"><MapPin size={16} /> Manage locations</Link>}
        >
          The matrix is built from your locations. Add a warehouse and at least two deliveries, or load a sample above.
        </EmptyState>
      </>
    );
  }

  return (
    <div className="space-y-5">
      {header}

      <Card className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full border-collapse text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="th sticky left-0 z-10 bg-slate-50">Location</th>
                {locations.map((l, i) => (
                  <th key={l.id} className="th whitespace-nowrap">{l.name}{i === 0 ? ' (W)' : ''}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {locations.map((row, i) => (
                <tr key={row.id} className="border-t border-slate-100">
                  <th className="td sticky left-0 z-10 whitespace-nowrap bg-slate-50 text-left font-semibold text-navy">{row.name}</th>
                  {locations.map((col, j) => {
                    if (i === j) {
                      return <td key={col.id} className="td bg-slate-50 text-center text-slate-400">0</td>;
                    }
                    const raw = distances[pairKey(row.id, col.id)] ?? '';
                    const status = cellStatus(raw);
                    return (
                      <td key={col.id} className="p-1">
                        <input
                          type="number"
                          inputMode="decimal"
                          min="0"
                          step="any"
                          value={raw}
                          aria-label={`Distance from ${row.name} to ${col.name}`}
                          aria-invalid={status === 'invalid'}
                          onChange={(e) => setDistance(row.id, col.id, e.target.value)}
                          className={`w-20 rounded-lg border px-2 py-1.5 text-center tabular-nums outline-none focus:ring-2 ${
                            status === 'invalid'
                              ? 'border-red-400 bg-red-50 focus:ring-red-200'
                              : 'border-slate-200 focus:border-primary focus:ring-primary/20'
                          }`}
                        />
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="text-sm text-slate-600">
          <strong className="text-navy">{filled}</strong> of {total} distances entered
          <div className="mt-1 h-2 w-56 overflow-hidden rounded-full bg-slate-200">
            <div className="h-full rounded-full bg-success transition-all" style={{ width: `${total ? (filled / total) * 100 : 0}%` }} />
          </div>
        </div>
        {filled === total && invalid === 0 && locations.length >= 3 ? (
          <Link to="/optimizer" className="btn btn-primary">Go to Route Optimizer <ArrowRight size={16} /></Link>
        ) : null}
      </div>

      {invalid > 0 && <Alert tone="error">{invalid} distance{invalid > 1 ? 's are' : ' is'} invalid. Distances must be non-negative numbers.</Alert>}
      {invalid === 0 && filled < total && <Alert tone="info">Fill every off-diagonal cell before optimizing. Empty values are not accepted.</Alert>}
      <p className="text-xs text-slate-500">
        Distances are the values you enter, in any consistent unit (for example km). They are not looked up from a map.
      </p>
    </div>
  );
}
