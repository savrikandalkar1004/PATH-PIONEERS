import { Link } from 'react-router-dom';
import { Card, PageHeader } from '../components/ui.jsx';

const STACK = [
  ['Frontend', 'React, Vite, Tailwind CSS, Lucide icons, Chart.js'],
  ['Backend', 'Python, Flask, Flask-CORS'],
  ['Algorithms', 'Pure Python: Greedy Nearest Neighbour and Branch and Bound (no TSP libraries)'],
  ['Data', 'No database. Inputs and results live in React state for the session.'],
];

export default function About() {
  return (
    <div className="space-y-6">
      <PageHeader title="About Project" subtitle="PATH PIONEERS: Delivery Route and Cost Optimizer. A Design and Analysis of Algorithms (DAA) project." />

      <Card>
        <h2 className="mb-2 text-base font-bold text-navy">Problem statement</h2>
        <p className="text-sm text-slate-600">
          One vehicle starts at a warehouse, must visit every delivery location exactly once and return to the warehouse. Find the
          route with the smallest total distance. This is the Travelling Salesman Problem (TSP), which is NP-hard: no known algorithm
          solves every instance in polynomial time.
        </p>
        <p className="mt-2 text-sm text-slate-600">
          Assumptions: distances are entered manually, symmetric and non-negative, and the diagonal is 0. They are not real map distances.
        </p>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-t-4 border-t-warning">
          <h2 className="mb-2 text-base font-bold text-navy">Greedy Nearest Neighbour</h2>
          <ol className="list-decimal space-y-1 pl-5 text-sm text-slate-600">
            <li>Start at the warehouse and mark it visited.</li>
            <li>Move to the nearest unvisited location (ties: lowest index).</li>
            <li>Repeat until all locations are visited.</li>
            <li>Return to the warehouse.</li>
          </ol>
          <p className="mt-3 text-sm"><strong>Time</strong> O(n²) · <strong>Space</strong> O(n) · Not guaranteed optimal.</p>
        </Card>
        <Card className="border-t-4 border-t-primary">
          <h2 className="mb-2 text-base font-bold text-navy">Branch and Bound</h2>
          <ol className="list-decimal space-y-1 pl-5 text-sm text-slate-600">
            <li>Build routes one location at a time from the warehouse (branching).</li>
            <li>For each partial route compute a lower bound on any completion: cost so far + the cheapest edge out of the current location + the cheapest outgoing edge of every unvisited location.</li>
            <li>Discard the branch if that bound cannot beat the best complete tour found so far (pruning).</li>
            <li>Keep the best complete tour; the result is provably optimal.</li>
          </ol>
          <p className="mt-3 text-sm"><strong>Time</strong> O(n!) worst case · <strong>Space</strong> O(n²) · Guaranteed optimal.</p>
        </Card>
      </div>

      <Card>
        <h2 className="mb-2 text-base font-bold text-navy">Technology</h2>
        <dl className="divide-y divide-slate-100 text-sm">
          {STACK.map(([k, v]) => (
            <div key={k} className="flex flex-col gap-1 py-2 sm:flex-row">
              <dt className="w-32 shrink-0 font-semibold text-navy">{k}</dt>
              <dd className="text-slate-600">{v}</dd>
            </div>
          ))}
        </dl>
      </Card>

      <Card>
        <h2 className="mb-2 text-base font-bold text-navy">Limitations and future scope</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm text-slate-600">
          <li>Branch and Bound is capped at a small number of locations because of its O(n!) worst case.</li>
          <li>Single vehicle, symmetric distances, no time windows or capacities.</li>
          <li>Future work: real map distances, multiple vehicles, stronger bounds (1-trees, reduced cost matrices), saved projects.</li>
        </ul>
        <div className="mt-4"><Link to="/optimizer" className="btn btn-primary btn-sm">Try the optimizer</Link></div>
      </Card>
    </div>
  );
}
