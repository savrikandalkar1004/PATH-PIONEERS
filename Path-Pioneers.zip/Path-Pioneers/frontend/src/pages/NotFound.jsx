import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { EmptyState } from '../components/ui.jsx';

export default function NotFound() {
  return (
    <EmptyState icon={Compass} title="Page not found" action={<Link to="/" className="btn btn-primary">Back to dashboard</Link>}>
      That route does not exist. Use the sidebar to get back on track.
    </EmptyState>
  );
}
