import { Route, Routes } from 'react-router-dom';
import DashboardLayout from './layouts/DashboardLayout.jsx';
import Dashboard from './pages/Dashboard.jsx';
import ManageLocations from './pages/ManageLocations.jsx';
import DistanceMatrix from './pages/DistanceMatrix.jsx';
import RouteOptimizer from './pages/RouteOptimizer.jsx';
import AlgorithmComparison from './pages/AlgorithmComparison.jsx';
import PerformanceAnalysis from './pages/PerformanceAnalysis.jsx';
import About from './pages/About.jsx';
import NotFound from './pages/NotFound.jsx';

export default function App() {
  return (
    <Routes>
      <Route element={<DashboardLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="locations" element={<ManageLocations />} />
        <Route path="matrix" element={<DistanceMatrix />} />
        <Route path="optimizer" element={<RouteOptimizer />} />
        <Route path="comparison" element={<AlgorithmComparison />} />
        <Route path="performance" element={<PerformanceAnalysis />} />
        <Route path="about" element={<About />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
