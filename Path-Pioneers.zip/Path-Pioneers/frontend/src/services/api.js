// Thin wrapper around fetch for the Flask backend.

const BASE = import.meta.env.VITE_API_URL || 'http://127.0.0.1:5000';

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(`Cannot reach the backend at ${BASE}. Start it with "python app.py" in the backend folder.`, 0);
  }
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON response */
  }
  if (!res.ok) throw new ApiError(data?.error || `Request failed (HTTP ${res.status}).`, res.status);
  return data;
}

export const api = {
  health: () => request('/api/health'),
  greedy: (problem) => request('/api/optimize/greedy', { method: 'POST', body: problem }),
  branchBound: (problem) => request('/api/optimize/branch-bound', { method: 'POST', body: problem }),
  compare: (problem) => request('/api/optimize/compare', { method: 'POST', body: problem }),
  performance: (params) => request('/api/performance/test', { method: 'POST', body: params }),
};
