import { useId } from 'react';
import { formatDistance } from '../utils/format';

/**
 * SVG route visualisation. This is a schematic graph, NOT a map:
 * node positions are evenly spaced on a circle and carry no geographic meaning.
 * Edge labels are the manually entered distances.
 *
 *  names   : location names (index 0 = warehouse)
 *  matrix  : numeric distance matrix
 *  route   : indices, starts and ends at 0
 *  variant : 'greedy' (orange, dashed) | 'bb' (blue, solid)
 */
export default function RouteGraph({ names, matrix, route, variant = 'bb' }) {
  const uid = useId().replace(/:/g, '');
  const W = 560;
  const H = 420;
  const cx = W / 2;
  const cy = H / 2;
  const R = 135;
  const r = 20;
  const color = variant === 'greedy' ? '#F59E0B' : '#2563EB';
  const dash = variant === 'greedy' ? '8 6' : undefined;
  const markerId = `arrow-${uid}`;
  const n = names.length;

  const pos = names.map((_, i) => {
    const a = -Math.PI / 2 + (2 * Math.PI * i) / n; // warehouse at the top
    return { x: cx + R * Math.cos(a), y: cy + R * Math.sin(a), cos: Math.cos(a), sin: Math.sin(a) };
  });

  const order = {};
  route.slice(0, -1).forEach((idx, step) => {
    order[idx] = step;
  });

  const edges = [];
  for (let k = 0; k < route.length - 1; k += 1) {
    const from = route[k];
    const to = route[k + 1];
    if (from === to) continue;
    const s = pos[from];
    const e = pos[to];
    const dx = e.x - s.x;
    const dy = e.y - s.y;
    const len = Math.hypot(dx, dy) || 1;
    // bend each edge to the right of its direction so A->B and B->A never overlap
    const c = { x: (s.x + e.x) / 2 - (dy / len) * 22, y: (s.y + e.y) / 2 + (dx / len) * 22 };
    const startDir = { x: c.x - s.x, y: c.y - s.y };
    const endDir = { x: e.x - c.x, y: e.y - c.y };
    const sl = Math.hypot(startDir.x, startDir.y) || 1;
    const el = Math.hypot(endDir.x, endDir.y) || 1;
    const p0 = { x: s.x + (startDir.x / sl) * (r + 2), y: s.y + (startDir.y / sl) * (r + 2) };
    const p1 = { x: e.x - (endDir.x / el) * (r + 5), y: e.y - (endDir.y / el) * (r + 5) };
    edges.push({
      key: `${from}-${to}-${k}`,
      d: `M ${p0.x} ${p0.y} Q ${c.x} ${c.y} ${p1.x} ${p1.y}`,
      lx: 0.25 * s.x + 0.5 * c.x + 0.25 * e.x,
      ly: 0.25 * s.y + 0.5 * c.y + 0.25 * e.y,
      label: formatDistance(matrix[from][to]),
    });
  }

  const short = (s) => (s.length > 14 ? `${s.slice(0, 13)}…` : s);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label={`Route: ${route.map((i) => names[i]).join(' to ')}`}>
      <defs>
        <marker id={markerId} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto">
          <path d="M0,0 L10,5 L0,10 z" fill={color} />
        </marker>
      </defs>

      {edges.map((e) => (
        <g key={e.key}>
          <path d={e.d} fill="none" stroke={color} strokeWidth="2.5" strokeDasharray={dash} markerEnd={`url(#${markerId})`} />
          <text x={e.lx} y={e.ly + 4} textAnchor="middle" fontSize="12" fontWeight="600" fill="#101B35" stroke="#fff" strokeWidth="4" paintOrder="stroke">
            {e.label}
          </text>
        </g>
      ))}

      {names.map((name, i) => {
        const p = pos[i];
        const isWarehouse = i === 0;
        const lx = p.x + (r + 10) * p.cos;
        const ly = p.y + (r + 10) * p.sin + 4;
        const anchor = p.cos > 0.3 ? 'start' : p.cos < -0.3 ? 'end' : 'middle';
        return (
          <g key={i}>
            <circle cx={p.x} cy={p.y} r={r} fill={isWarehouse ? '#101B35' : '#fff'} stroke={isWarehouse ? '#101B35' : color} strokeWidth="2.5" />
            <text x={p.x} y={p.y + 5} textAnchor="middle" fontSize="14" fontWeight="700" fill={isWarehouse ? '#fff' : '#101B35'}>
              {isWarehouse ? 'W' : order[i]}
            </text>
            <text x={lx} y={ly + (p.sin > 0.3 ? 8 : p.sin < -0.3 ? -6 : 0)} textAnchor={anchor} fontSize="12" fontWeight="600" fill="#334155">
              {short(name)}
              <title>{name}</title>
            </text>
          </g>
        );
      })}
    </svg>
  );
}
