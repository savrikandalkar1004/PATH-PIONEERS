import { AlertCircle, CheckCircle2, Info, Loader2, TriangleAlert } from 'lucide-react';

export function Card({ className = '', children }) {
  return <section className={`card ${className}`}>{children}</section>;
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold text-navy">{title}</h1>
        {subtitle && <p className="mt-1 max-w-3xl text-sm text-slate-500">{subtitle}</p>}
      </div>
      {action && <div className="flex flex-wrap gap-2">{action}</div>}
    </div>
  );
}

const TONES = {
  blue: 'bg-blue-50 text-primary',
  green: 'bg-green-50 text-success',
  orange: 'bg-amber-50 text-warning',
  navy: 'bg-slate-100 text-navy',
};

export function StatCard({ icon: Icon, label, value, hint, tone = 'blue' }) {
  return (
    <Card className="!p-4 sm:!p-5">
      <div className="flex items-center gap-3">
        <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${TONES[tone]}`}>
          <Icon size={20} />
        </div>
        <div className="min-w-0">
          <div className="truncate text-xs font-medium uppercase tracking-wide text-slate-500">{label}</div>
          <div className="text-2xl font-bold text-navy">{value}</div>
        </div>
      </div>
      {hint && <div className="mt-2 text-xs text-slate-500">{hint}</div>}
    </Card>
  );
}

const ALERTS = {
  info: { cls: 'border-blue-200 bg-blue-50 text-blue-900', Icon: Info },
  success: { cls: 'border-green-200 bg-green-50 text-green-900', Icon: CheckCircle2 },
  warning: { cls: 'border-amber-200 bg-amber-50 text-amber-900', Icon: TriangleAlert },
  error: { cls: 'border-red-200 bg-red-50 text-red-900', Icon: AlertCircle },
};

export function Alert({ tone = 'info', title, children, onClose }) {
  const { cls, Icon } = ALERTS[tone];
  return (
    <div role={tone === 'error' ? 'alert' : 'status'} className={`flex gap-3 rounded-xl border p-3 text-sm ${cls}`}>
      <Icon size={18} className="mt-0.5 shrink-0" />
      <div className="min-w-0 flex-1">
        {title && <div className="font-semibold">{title}</div>}
        <div>{children}</div>
      </div>
      {onClose && (
        <button onClick={onClose} className="text-xs font-semibold underline" aria-label="Dismiss">
          Dismiss
        </button>
      )}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, children, action }) {
  return (
    <div className="flex flex-col items-center rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-blue-50 text-primary">
        <Icon size={24} />
      </div>
      <h3 className="text-base font-semibold text-navy">{title}</h3>
      <p className="mt-1 max-w-md text-sm text-slate-500">{children}</p>
      {action && <div className="mt-4 flex flex-wrap justify-center gap-2">{action}</div>}
    </div>
  );
}

export function Spinner({ className = '' }) {
  return <Loader2 className={`animate-spin ${className}`} size={16} aria-label="Loading" />;
}
