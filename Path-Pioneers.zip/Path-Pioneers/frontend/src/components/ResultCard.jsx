import { ArrowRight, BadgeCheck, TriangleAlert } from 'lucide-react';
import { Card } from './ui.jsx';
import RouteGraph from './RouteGraph.jsx';
import { formatDistance, formatMs } from '../utils/format';

/**
 * One algorithm's result: route sequence, distance, time, visited count + graph.
 *  kind    : 'greedy' | 'bb'
 *  result  : backend result object
 *  problem : { locations, distance_matrix } the result was computed from
 */
export default function ResultCard({ kind, result, problem }) {
  const isBB = kind === 'bb';
  return (
    <Card className={`border-t-4 ${isBB ? 'border-t-primary' : 'border-t-warning'}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-base font-bold text-navy">{isBB ? 'Branch and Bound result' : 'Greedy algorithm result'}</h3>
        {isBB ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2.5 py-1 text-xs font-semibold text-success">
            <BadgeCheck size={14} /> Optimal route
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700">
            <TriangleAlert size={14} /> Heuristic, not guaranteed optimal
          </span>
        )}
      </div>

      <dl className="mt-4 grid grid-cols-3 gap-3">
        <div className="rounded-xl bg-slate-50 p-3">
          <dt className="text-xs text-slate-500">Total distance</dt>
          <dd className="text-xl font-bold text-navy">{formatDistance(result.distance)}</dd>
        </div>
        <div className="rounded-xl bg-slate-50 p-3">
          <dt className="text-xs text-slate-500">Execution time</dt>
          <dd className="text-sm font-bold text-navy sm:text-base">{formatMs(result.execution_time)}</dd>
        </div>
        <div className="rounded-xl bg-slate-50 p-3">
          <dt className="text-xs text-slate-500">Locations visited</dt>
          <dd className="text-xl font-bold text-navy">{result.locations_visited}</dd>
        </div>
      </dl>

      <div className="mt-4">
        <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Route sequence</div>
        <div className="flex flex-wrap items-center gap-1.5">
          {result.route.map((name, i) => (
            <span key={i} className="inline-flex items-center gap-1.5">
              <span className={`rounded-lg px-2 py-1 text-xs font-semibold ${i === 0 || i === result.route.length - 1 ? 'bg-navy text-white' : 'bg-blue-50 text-primary'}`}>
                {name}
              </span>
              {i < result.route.length - 1 && <ArrowRight size={14} className="text-slate-400" />}
            </span>
          ))}
        </div>
      </div>

      {isBB && result.nodes_explored !== undefined && (
        <p className="mt-3 text-xs text-slate-500">
          Search effort: {result.nodes_explored.toLocaleString()} nodes explored, {result.branches_pruned.toLocaleString()} branches pruned by the lower bound.
        </p>
      )}

      <div className="mt-4 rounded-xl border border-slate-100 bg-slate-50/50 p-2">
        <RouteGraph names={problem.locations} matrix={problem.distance_matrix} route={result.route_indices} variant={kind} />
        <p className="px-2 pb-1 text-center text-[11px] text-slate-500">
          Schematic graph (not a map). W = warehouse, numbers = visit order, edge labels = entered distances.
        </p>
      </div>
    </Card>
  );
}
