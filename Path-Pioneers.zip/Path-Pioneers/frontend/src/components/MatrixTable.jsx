import { formatDistance } from '../utils/format';

/** Read-only distance matrix. `matrix` may hold numbers or strings ('' = not entered). */
export default function MatrixTable({ names, matrix }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200">
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead className="bg-slate-50">
          <tr>
            <th className="th">Location</th>
            {names.map((n, i) => (
              <th key={i} className="th whitespace-nowrap">{n}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {names.map((rowName, i) => (
            <tr key={i}>
              <th className="td whitespace-nowrap bg-slate-50 text-left font-semibold text-navy">{rowName}</th>
              {names.map((_, j) => {
                const v = matrix[i][j];
                const empty = v === '' || v === undefined || Number.isNaN(v);
                return (
                  <td key={j} className={`td tabular-nums ${i === j ? 'text-slate-300' : empty ? 'text-slate-300' : ''}`}>
                    {empty ? '—' : typeof v === 'number' ? formatDistance(v) : v}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
