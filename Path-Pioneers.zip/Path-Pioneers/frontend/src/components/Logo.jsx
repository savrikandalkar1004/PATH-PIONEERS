// Route/path-inspired logo mark + wordmark.
export function LogoMark({ size = 36 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden="true">
      <rect width="40" height="40" rx="10" fill="#2563EB" />
      <path d="M11 29C11 20 20 24 20 17S29 14 29 11" stroke="#fff" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <circle cx="11" cy="29" r="3" fill="#fff" />
      <circle cx="29" cy="11" r="3" fill="#F59E0B" />
    </svg>
  );
}

export default function Logo({ light = false, showTagline = false }) {
  return (
    <div className="flex items-center gap-3">
      <LogoMark />
      <div className="leading-tight">
        <div className={`text-base font-extrabold tracking-wide ${light ? 'text-white' : 'text-navy'}`}>PATH PIONEERS</div>
        {showTagline && <div className="text-[10px] text-slate-400">Delivery Route Optimizer</div>}
      </div>
    </div>
  );
}
