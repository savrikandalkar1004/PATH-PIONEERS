/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: '#101B35',
        primary: '#2563EB',
        surface: '#F5F7FB',
        success: '#16A34A',
        warning: '#F59E0B',
      },
      boxShadow: {
        card: '0 1px 2px rgba(16,27,53,0.04), 0 4px 16px rgba(16,27,53,0.06)',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: 0, transform: 'translateY(6px)' }, '100%': { opacity: 1, transform: 'none' } },
      },
      animation: { 'fade-in': 'fadeIn 0.3s ease-out' },
    },
  },
  plugins: [],
};
