import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The dev server runs on 5173; the Flask API on 5000 (CORS is enabled there).
export default defineConfig({
  plugins: [react()],
  server: { port: 5173 },
});
