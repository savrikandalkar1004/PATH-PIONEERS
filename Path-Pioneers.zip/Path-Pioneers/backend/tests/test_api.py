"""
API tests (Flask test client - no server needs to be running).

Run from backend/:  python -m unittest discover -s tests -t . -v
"""

import unittest

from app import create_app

BRIEF = {
    "locations": ["Warehouse", "A", "B", "C"],
    "distance_matrix": [
        [0, 10, 15, 20],
        [10, 0, 35, 25],
        [15, 35, 0, 30],
        [20, 25, 30, 0],
    ],
}
# Greedy = 37, optimal = 35 (see test_algorithms.py)
GREEDY_FAILS = {
    "locations": ["W", "A", "B", "C"],
    "distance_matrix": [[0, 12, 4, 18], [12, 0, 3, 19], [4, 3, 0, 2], [18, 19, 2, 0]],
}


def big_problem(n):
    names = ["W"] + [f"L{i}" for i in range(1, n)]
    matrix = [[0 if i == j else 1 for j in range(n)] for i in range(n)]
    return {"locations": names, "distance_matrix": matrix}


class ApiTestCase(unittest.TestCase):
    def setUp(self):
        self.client = create_app({"TESTING": True, "MAX_BB_LOCATIONS": 12}).test_client()


class TestHealth(ApiTestCase):
    def test_health(self):
        r = self.client.get("/api/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["status"], "ok")
        self.assertEqual(r.json["max_branch_bound_locations"], 12)


class TestOptimize(ApiTestCase):
    def test_greedy(self):
        r = self.client.post("/api/optimize/greedy", json=BRIEF)
        self.assertEqual(r.status_code, 200)
        g = r.json["greedy"]
        self.assertEqual(g["route"], ["Warehouse", "A", "C", "B", "Warehouse"])
        self.assertEqual(g["distance"], 80)
        self.assertEqual(g["locations_visited"], 4)
        self.assertGreaterEqual(g["execution_time"], 0)

    def test_branch_bound(self):
        r = self.client.post("/api/optimize/branch-bound", json=BRIEF)
        self.assertEqual(r.status_code, 200)
        b = r.json["branch_and_bound"]
        self.assertEqual(b["distance"], 80)
        self.assertEqual(b["route"][0], "Warehouse")
        self.assertEqual(b["route"][-1], "Warehouse")
        self.assertIn("nodes_explored", b)

    def test_compare_greedy_suboptimal(self):
        r = self.client.post("/api/optimize/compare", json=GREEDY_FAILS)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["greedy"]["distance"], 37)
        self.assertEqual(r.json["branch_and_bound"]["distance"], 35)
        c = r.json["comparison"]
        self.assertEqual(c["distance_saved"], 2)
        self.assertAlmostEqual(c["improvement_percent"], 2 / 37 * 100)
        self.assertFalse(c["greedy_is_optimal"])

    def test_compare_same_distance(self):
        c = self.client.post("/api/optimize/compare", json=BRIEF).json["comparison"]
        self.assertEqual(c["distance_saved"], 0)
        self.assertEqual(c["improvement_percent"], 0)
        self.assertTrue(c["greedy_is_optimal"])

    def test_zero_distance_improvement_is_safe(self):
        body = {"locations": ["W", "A", "B"], "distance_matrix": [[0] * 3 for _ in range(3)]}
        r = self.client.post("/api/optimize/compare", json=body)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["comparison"]["improvement_percent"], 0)

    def test_single_location(self):
        body = {"locations": ["W"], "distance_matrix": [[0]]}
        r = self.client.post("/api/optimize/compare", json=body)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["branch_and_bound"]["route"], ["W", "W"])


class TestValidation(ApiTestCase):
    def post(self, path, body):
        return self.client.post(path, json=body)

    def test_bad_requests_return_400(self):
        good = BRIEF["distance_matrix"]
        cases = {
            "missing locations": {"distance_matrix": good},
            "missing matrix": {"locations": BRIEF["locations"]},
            "empty name": {"locations": ["W", "", "B", "C"], "distance_matrix": good},
            "duplicate names": {"locations": ["W", "A", "a", "C"], "distance_matrix": good},
            "size mismatch": {"locations": ["W", "A", "B"], "distance_matrix": good},
            "negative": {"locations": BRIEF["locations"],
                         "distance_matrix": [[0, -1, 1, 1], [-1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 0]]},
            "asymmetric": {"locations": BRIEF["locations"],
                           "distance_matrix": [[0, 1, 1, 1], [2, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 0]]},
            "non numeric": {"locations": ["W", "A"], "distance_matrix": [[0, "x"], ["x", 0]]},
            "not an object": [1, 2, 3],
        }
        for path in ("/api/optimize/greedy", "/api/optimize/branch-bound", "/api/optimize/compare"):
            for name, body in cases.items():
                with self.subTest(path=path, case=name):
                    r = self.post(path, body)
                    self.assertEqual(r.status_code, 400)
                    self.assertIn("error", r.json)

    def test_non_json_body(self):
        r = self.client.post("/api/optimize/greedy", data="not json", content_type="text/plain")
        self.assertEqual(r.status_code, 400)

    def test_too_large_for_branch_and_bound(self):
        big = big_problem(13)
        self.assertEqual(self.post("/api/optimize/branch-bound", big).status_code, 422)
        self.assertEqual(self.post("/api/optimize/compare", big).status_code, 422)
        # Greedy can still handle it
        self.assertEqual(self.post("/api/optimize/greedy", big).status_code, 200)

    def test_absolute_size_cap(self):
        self.assertEqual(self.post("/api/optimize/greedy", big_problem(501)).status_code, 422)

    def test_json_404_and_405(self):
        r = self.client.get("/api/nope")
        self.assertEqual(r.status_code, 404)
        self.assertIn("error", r.json)
        r = self.client.get("/api/optimize/greedy")
        self.assertEqual(r.status_code, 405)
        self.assertIn("error", r.json)


class TestPerformanceEndpoint(ApiTestCase):
    def test_runs_and_reports_real_measurements(self):
        r = self.client.post("/api/performance/test", json={"sizes": [3, 5, 7], "repeats": 3, "seed": 1})
        self.assertEqual(r.status_code, 200)
        rows = r.json["results"]
        self.assertEqual([x["delivery_locations"] for x in rows], [3, 5, 7])
        for row in rows:
            self.assertGreaterEqual(row["greedy"]["median_time_ms"], 0)
            self.assertLessEqual(row["branch_and_bound"]["distance"], row["greedy"]["distance"])
            self.assertFalse(row["branch_and_bound_skipped"])
            self.assertEqual(row["greedy"]["runs"], 3)

    def test_seed_makes_distances_reproducible(self):
        body = {"sizes": [4, 6], "repeats": 1, "seed": 99}
        a = self.client.post("/api/performance/test", json=body).json["results"]
        b = self.client.post("/api/performance/test", json=body).json["results"]
        self.assertEqual([r["greedy"]["distance"] for r in a], [r["greedy"]["distance"] for r in b])
        self.assertEqual([r["branch_and_bound"]["distance"] for r in a],
                         [r["branch_and_bound"]["distance"] for r in b])

    def test_branch_bound_skipped_when_too_large(self):
        r = self.client.post("/api/performance/test", json={"sizes": [13], "repeats": 1, "seed": 1})
        self.assertEqual(r.status_code, 200)
        row = r.json["results"][0]
        self.assertTrue(row["branch_and_bound_skipped"])
        self.assertIsNone(row["branch_and_bound"])
        self.assertIsNotNone(row["greedy"])

    def test_bad_parameters(self):
        bad = [
            {},
            {"sizes": []},
            {"sizes": [0]},
            {"sizes": [3.5]},
            {"sizes": ["3"]},
            {"sizes": [True]},
            {"sizes": [3], "repeats": 0},
            {"sizes": [3], "repeats": 99},
            {"sizes": [3], "seed": "x"},
            {"sizes": list(range(1, 30))},
        ]
        for body in bad:
            with self.subTest(body=body):
                self.assertEqual(self.client.post("/api/performance/test", json=body).status_code, 400)


if __name__ == "__main__":
    unittest.main()
