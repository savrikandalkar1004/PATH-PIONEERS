"""
Tests for Greedy Nearest Neighbour and Branch and Bound.

Run from the backend/ folder:
    python -m unittest discover -s tests -t . -v
(or `pytest` if you have it installed)

The key idea: a slow but obviously-correct BRUTE-FORCE solver is used only
inside the tests as an oracle. Branch and Bound must match it exactly on
hundreds of random instances, including ones that violate the triangle
inequality.
"""

import itertools
import math
import random
import unittest

from algorithms.branch_bound import DEFAULT_MAX_LOCATIONS, branch_and_bound, lower_bound
from algorithms.common import (
    InputTooLargeError,
    InvalidInputError,
    route_distance,
)
from algorithms.greedy import greedy_nearest_neighbour


# ----------------------------------------------------------------- helpers
def brute_force(matrix):
    """Oracle: try every permutation of the delivery cities. Returns min distance."""
    n = len(matrix)
    best = math.inf
    for perm in itertools.permutations(range(1, n)):
        best = min(best, route_distance(matrix, [0, *perm, 0]))
    return best


def random_matrix(n, rng, low=1, high=50):
    m = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            m[i][j] = m[j][i] = rng.randint(low, high)
    return m


def full_tree_nodes(n):
    """Number of nodes in the un-pruned search tree for n locations."""
    k = n - 1
    return sum(math.factorial(k) // math.factorial(k - d) for d in range(k + 1))


# The illustrative matrix from the project brief.
BRIEF = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0],
]

# Found by search (seed 7): Greedy = 37, optimum = 35.
GREEDY_FAILS_4 = [
    [0, 12, 4, 18],
    [12, 0, 3, 19],
    [4, 3, 0, 2],
    [18, 19, 2, 0],
]
# Greedy = 52, optimum = 45.
GREEDY_FAILS_5 = [
    [0, 16, 14, 2, 3],
    [16, 0, 18, 19, 11],
    [14, 18, 0, 11, 12],
    [2, 19, 11, 0, 20],
    [3, 11, 12, 20, 0],
]


class RouteInvariants:
    """Mixin: checks every valid answer must satisfy."""

    def check_route(self, matrix, result):
        n = len(matrix)
        route = result["route"]
        self.assertEqual(route[0], 0, "must start at warehouse")
        self.assertEqual(route[-1], 0, "must end at warehouse")
        self.assertEqual(len(route), n + 1)
        self.assertEqual(sorted(route[:-1]), list(range(n)), "each location exactly once")
        self.assertAlmostEqual(result["distance"], route_distance(matrix, route))


# ------------------------------------------------------------------ greedy
class TestGreedy(RouteInvariants, unittest.TestCase):
    def test_brief_matrix(self):
        r = greedy_nearest_neighbour(BRIEF)
        self.assertEqual(r["route"], [0, 1, 3, 2, 0])
        self.assertEqual(r["distance"], 80)

    def test_tie_goes_to_lowest_index(self):
        ones = [[0 if i == j else 1 for j in range(5)] for i in range(5)]
        self.assertEqual(greedy_nearest_neighbour(ones)["route"], [0, 1, 2, 3, 4, 0])

    def test_single_and_two_locations(self):
        self.assertEqual(greedy_nearest_neighbour([[0]])["route"], [0, 0])
        r = greedy_nearest_neighbour([[0, 7], [7, 0]])
        self.assertEqual((r["route"], r["distance"]), ([0, 1, 0], 14))


# --------------------------------------------------------- branch and bound
class TestBranchAndBoundKnownAnswers(RouteInvariants, unittest.TestCase):
    def test_four_locations_brief_matrix(self):
        r = branch_and_bound(BRIEF)
        self.check_route(BRIEF, r)
        self.assertEqual(r["distance"], 80)  # 0-1-3-2-0 and its reverse

    def test_five_locations(self):
        m = [
            [0, 3, 1, 5, 8],
            [3, 0, 6, 7, 9],
            [1, 6, 0, 4, 2],
            [5, 7, 4, 0, 3],
            [8, 9, 2, 3, 0],
        ]
        r = branch_and_bound(m)
        self.check_route(m, r)
        self.assertEqual(r["distance"], brute_force(m))
        # hand-checked: 0->1->3->4->2->0 = 3 + 7 + 3 + 2 + 1 = 16
        self.assertEqual(r["distance"], 16)

    def test_six_locations(self):
        m = random_matrix(6, random.Random(2024))
        r = branch_and_bound(m)
        self.check_route(m, r)
        self.assertEqual(r["distance"], brute_force(m))

    def test_greedy_is_not_optimal_but_bb_is(self):
        for m, greedy_d, opt_d in ((GREEDY_FAILS_4, 37, 35), (GREEDY_FAILS_5, 52, 45)):
            g = greedy_nearest_neighbour(m)
            b = branch_and_bound(m)
            self.check_route(m, g)
            self.check_route(m, b)
            self.assertEqual(g["distance"], greedy_d)
            self.assertEqual(b["distance"], opt_d)
            self.assertEqual(brute_force(m), opt_d)
            self.assertLess(b["distance"], g["distance"])

    def test_both_algorithms_same_distance(self):
        g, b = greedy_nearest_neighbour(BRIEF), branch_and_bound(BRIEF)
        self.assertEqual(g["distance"], b["distance"])

    def test_equal_distances(self):
        for n in (4, 6, 8):
            m = [[0 if i == j else 5 for j in range(n)] for i in range(n)]
            g, b = greedy_nearest_neighbour(m), branch_and_bound(m)
            self.check_route(m, b)
            self.assertEqual(b["distance"], 5 * n)
            self.assertEqual(g["distance"], 5 * n)

    def test_all_zero_distances(self):
        m = [[0] * 5 for _ in range(5)]
        r = branch_and_bound(m)
        self.check_route(m, r)
        self.assertEqual(r["distance"], 0)

    def test_tiny_inputs(self):
        self.assertEqual(branch_and_bound([[0]])["route"], [0, 0])
        r = branch_and_bound([[0, 7], [7, 0]])
        self.assertEqual((r["route"], r["distance"]), ([0, 1, 0], 14))

    def test_float_distances(self):
        m = [[0, 1.5, 2.25], [1.5, 0, 3.0], [2.25, 3.0, 0]]
        r = branch_and_bound(m)
        self.assertAlmostEqual(r["distance"], 6.75)

    def test_deterministic(self):
        self.assertEqual(branch_and_bound(GREEDY_FAILS_5), branch_and_bound(GREEDY_FAILS_5))


class TestBranchAndBoundAgainstOracle(RouteInvariants, unittest.TestCase):
    """Randomised check against brute force (this is the main correctness proof)."""

    def test_random_instances_match_brute_force(self):
        rng = random.Random(12345)
        for trial in range(300):
            n = rng.randint(1, 8)
            # small value range => many ties; large range => few ties
            high = rng.choice([3, 10, 100])
            m = random_matrix(n, rng, low=0, high=high)
            for seed in (True, False):
                b = branch_and_bound(m, seed_with_greedy=seed)
                g = greedy_nearest_neighbour(m)
                self.check_route(m, b)
                self.check_route(m, g)
                self.assertEqual(b["distance"], brute_force(m), f"trial {trial}, n={n}, seed={seed}")
                self.assertLessEqual(b["distance"], g["distance"])

    def test_non_metric_instances(self):
        """Triangle inequality violated on purpose: the bound must still be valid."""
        rng = random.Random(99)
        for _ in range(100):
            n = rng.randint(4, 8)
            m = random_matrix(n, rng, low=1, high=1000)
            self.assertEqual(branch_and_bound(m)["distance"], brute_force(m))


class TestLowerBoundIsAdmissible(unittest.TestCase):
    """lower_bound() must NEVER exceed the true cost of the best completion."""

    def test_bound_never_overestimates(self):
        rng = random.Random(555)
        checked = 0
        for _ in range(150):
            n = rng.randint(3, 7)
            m = random_matrix(n, rng, low=0, high=rng.choice([5, 50]))
            others = list(range(1, n))
            rng.shuffle(others)
            k = rng.randint(0, n - 1)  # length of the delivery prefix
            prefix = others[:k]
            rest = others[k:]
            path = [0] + prefix
            cost = route_distance(m, path)
            current = path[-1]

            true_best = min(
                (route_distance(m, path + list(p) + [0]) for p in itertools.permutations(rest)),
                default=math.inf,
            )
            lb = lower_bound(m, current, cost, tuple(rest))
            self.assertLessEqual(lb, true_best + 1e-9, f"path={path}, rest={rest}")
            checked += 1
        self.assertEqual(checked, 150)

    def test_bound_exact_when_nothing_left(self):
        m = BRIEF
        self.assertEqual(lower_bound(m, 3, 55, ()), 55 + m[3][0])


class TestPruningActuallyHappens(unittest.TestCase):
    """Guards against 'brute force called Branch and Bound'."""

    def test_far_fewer_nodes_than_full_tree(self):
        rng = random.Random(8)
        m = random_matrix(10, rng, low=1, high=100)
        r = branch_and_bound(m)
        full = full_tree_nodes(10)
        self.assertGreater(r["branches_pruned"], 0)
        self.assertLess(r["nodes_explored"], full / 10)

    def test_seed_does_not_change_distance(self):
        rng = random.Random(3)
        m = random_matrix(9, rng)
        a = branch_and_bound(m, seed_with_greedy=True)
        b = branch_and_bound(m, seed_with_greedy=False)
        self.assertEqual(a["distance"], b["distance"])
        self.assertLessEqual(a["nodes_explored"], b["nodes_explored"])

    def test_bb_never_worse_than_greedy_on_larger_inputs(self):
        rng = random.Random(77)
        for n in (9, 10, 11):
            m = random_matrix(n, rng)
            self.assertLessEqual(branch_and_bound(m)["distance"], greedy_nearest_neighbour(m)["distance"])


# ------------------------------------------------------------ invalid input
class TestInvalidInput(unittest.TestCase):
    BAD = {
        "not a list": "hello",
        "none": None,
        "empty": [],
        "row not list": [[0, 1], 5],
        "not square": [[0, 1, 2], [1, 0, 3]],
        "negative": [[0, -1], [-1, 0]],
        "non-numeric": [[0, "a"], ["a", 0]],
        "bool": [[0, True], [True, 0]],
        "nan": [[0, float("nan")], [float("nan"), 0]],
        "inf": [[0, float("inf")], [float("inf"), 0]],
        "nonzero diagonal": [[1, 2], [2, 0]],
        "asymmetric": [[0, 1], [2, 0]],
        "None entry": [[0, None], [None, 0]],
    }

    def test_both_algorithms_reject_bad_matrices(self):
        for name, matrix in self.BAD.items():
            with self.subTest(name):
                with self.assertRaises(InvalidInputError):
                    greedy_nearest_neighbour(matrix)
                with self.assertRaises(InvalidInputError):
                    branch_and_bound(matrix)

    def test_size_limit(self):
        m = random_matrix(DEFAULT_MAX_LOCATIONS + 1, random.Random(1))
        with self.assertRaises(InputTooLargeError):
            branch_and_bound(m)
        # raising the limit explicitly is allowed (small case to stay fast)
        small = random_matrix(5, random.Random(1))
        with self.assertRaises(InputTooLargeError):
            branch_and_bound(small, max_locations=4)
        self.assertEqual(branch_and_bound(small, max_locations=5)["distance"], brute_force(small))

    def test_bad_max_locations(self):
        for bad in (0, -3, 2.5, "9", None, True):
            with self.subTest(bad=bad):
                with self.assertRaises(InvalidInputError):
                    branch_and_bound(BRIEF, max_locations=bad)

    def test_input_not_mutated(self):
        import copy

        m = copy.deepcopy(GREEDY_FAILS_5)
        branch_and_bound(m)
        greedy_nearest_neighbour(m)
        self.assertEqual(m, GREEDY_FAILS_5)


if __name__ == "__main__":
    unittest.main()
