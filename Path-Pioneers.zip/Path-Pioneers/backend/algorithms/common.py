"""
Shared helpers for the Path Pioneers TSP algorithms.

Both Greedy and Branch and Bound validate their input with the SAME function,
so they are guaranteed to be solving the same, well-formed problem.

Problem definition (as required by the project):
    * Location 0 is the warehouse (start and end of the tour).
    * Every other location is visited exactly once.
    * Distances are non-negative, symmetric, and d[i][i] == 0.
"""

import math

# Two floats closer than this are treated as equal (symmetry check, pruning).
EPSILON = 1e-9


class InvalidInputError(ValueError):
    """The distance matrix (or another argument) is malformed."""


class InputTooLargeError(InvalidInputError):
    """The instance is too big for the requested algorithm."""


def _is_number(x):
    # bool is a subclass of int in Python, but True/False is not a distance.
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def validate_distance_matrix(matrix):
    """
    Check that `matrix` is a valid symmetric TSP distance matrix.

    Returns n (the number of locations, warehouse included).
    Raises InvalidInputError with a human-readable message otherwise.
    Time: O(n^2).
    """
    if not isinstance(matrix, (list, tuple)):
        raise InvalidInputError("Distance matrix must be a list of rows.")
    n = len(matrix)
    if n == 0:
        raise InvalidInputError("Distance matrix is empty; at least the warehouse is required.")

    for i, row in enumerate(matrix):
        if not isinstance(row, (list, tuple)):
            raise InvalidInputError(f"Row {i} of the distance matrix is not a list.")
        if len(row) != n:
            raise InvalidInputError(
                f"Distance matrix must be square: row {i} has {len(row)} entries, expected {n}."
            )
        for j, value in enumerate(row):
            if not _is_number(value):
                raise InvalidInputError(f"Distance [{i}][{j}] is not a number: {value!r}.")
            if math.isnan(value) or math.isinf(value):
                raise InvalidInputError(f"Distance [{i}][{j}] must be finite, got {value!r}.")
            if value < 0:
                raise InvalidInputError(f"Distance [{i}][{j}] is negative ({value}).")

    for i in range(n):
        if matrix[i][i] != 0:
            raise InvalidInputError(f"Diagonal entry [{i}][{i}] must be 0, got {matrix[i][i]}.")
        for j in range(i + 1, n):
            if abs(matrix[i][j] - matrix[j][i]) > EPSILON:
                raise InvalidInputError(
                    f"Matrix is not symmetric: [{i}][{j}]={matrix[i][j]} but [{j}][{i}]={matrix[j][i]}."
                )
    return n


def route_distance(matrix, route):
    """Total length of `route` (a list of indices, including the return leg)."""
    return sum(matrix[route[k]][route[k + 1]] for k in range(len(route) - 1))
