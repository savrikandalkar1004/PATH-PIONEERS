"""
Greedy Nearest Neighbour algorithm for the Travelling Salesman Problem.

Idea
----
Start at the warehouse (index 0). Repeatedly drive to the closest location
that has not been visited yet. When everything is visited, return to the
warehouse.

Properties
----------
* Time complexity : O(n^2)  - n-1 steps, each scans up to n candidates.
* Space complexity: O(n)    - the visited array and the route list.
* NOT guaranteed optimal. A locally cheap move can force a very expensive
  move later (see tests/test_algorithms.py for a concrete counter-example).

Tie-breaking
------------
If two unvisited locations are equally close, the one with the LOWEST INDEX
is chosen (the scan uses a strict '<' comparison), so results are
deterministic.
"""

from .common import route_distance, validate_distance_matrix


def greedy_nearest_neighbour(matrix):
    """
    Returns a dict:
        route    : list of location indices, starts and ends with 0
        distance : total tour length
    Raises InvalidInputError for a malformed matrix.
    """
    n = validate_distance_matrix(matrix)

    visited = [False] * n
    visited[0] = True
    route = [0]
    current = 0

    for _ in range(n - 1):
        nearest = -1
        nearest_dist = float("inf")
        for j in range(n):
            # strict '<' keeps the lowest index on ties
            if not visited[j] and matrix[current][j] < nearest_dist:
                nearest, nearest_dist = j, matrix[current][j]
        visited[nearest] = True
        route.append(nearest)
        current = nearest

    route.append(0)  # return to the warehouse
    return {"route": route, "distance": route_distance(matrix, route)}
