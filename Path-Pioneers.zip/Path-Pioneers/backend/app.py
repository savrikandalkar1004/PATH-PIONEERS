"""
Path Pioneers - Flask application entry point.

Run:  python app.py        (serves http://127.0.0.1:5000)
"""

import os

from flask import Flask, jsonify
from flask_cors import CORS
from werkzeug.exceptions import HTTPException

from algorithms.branch_bound import DEFAULT_MAX_LOCATIONS
from algorithms.common import InputTooLargeError, InvalidInputError
from routes.optimizer import optimizer_bp

# Origins allowed to call the API (the Vite dev server by default).
DEFAULT_ORIGINS = ["http://localhost:5173", "http://127.0.0.1:5173"]


def create_app(config=None):
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024  # 1 MB request limit
    app.config["MAX_BB_LOCATIONS"] = int(
        os.environ.get("MAX_BB_LOCATIONS", DEFAULT_MAX_LOCATIONS)
    )
    if config:
        app.config.update(config)

    origins = os.environ.get("CORS_ORIGINS")
    origins = [o.strip() for o in origins.split(",")] if origins else DEFAULT_ORIGINS
    CORS(app, resources={r"/api/*": {"origins": origins}})

    app.register_blueprint(optimizer_bp)

    # ---- JSON error responses (never HTML) ----
    @app.errorhandler(InputTooLargeError)
    def too_large(err):
        return jsonify({"error": str(err)}), 422

    @app.errorhandler(InvalidInputError)
    def invalid(err):
        return jsonify({"error": str(err)}), 400

    @app.errorhandler(HTTPException)
    def http_error(err):
        return jsonify({"error": err.description}), err.code

    @app.errorhandler(Exception)
    def unexpected(err):
        app.logger.exception("Unhandled error")
        return jsonify({"error": "Internal server error."}), 500

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
